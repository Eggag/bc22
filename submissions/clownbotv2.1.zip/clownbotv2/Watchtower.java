package clownbotv2;

import battlecode.common.GameActionException;

public class Watchtower extends RobotPlayer {
    static void runWatchtower() throws GameActionException {

    }
}