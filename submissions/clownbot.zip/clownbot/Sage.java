package clownbot;

import battlecode.common.GameActionException;

public class Sage extends RobotPlayer {
    static void runSage() throws GameActionException {

    }
}