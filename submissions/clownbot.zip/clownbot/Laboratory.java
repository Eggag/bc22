package clownbot;

import battlecode.common.GameActionException;

public class Laboratory extends RobotPlayer {
    static void runLaboratory() throws GameActionException {

    }
}