package clownbot;

import battlecode.common.GameActionException;

public class Builder extends RobotPlayer {
    static void runBuilder() throws GameActionException {

    }
}