package nbpv2;

import battlecode.common.*;

import java.util.ArrayList;
import java.util.Map;

public class Watchtower extends RobotPlayer {
    static void runWatchtower() throws GameActionException {

    }
}