package orzbotv2;

import battlecode.common.*;

import java.util.ArrayList;
import java.util.Map;

public class Laboratory extends RobotPlayer {
    static void runLaboratory() throws GameActionException {

    }
}