package orzbotv2;

import battlecode.common.*;

import java.util.ArrayList;
import java.util.Map;

public class Sage extends RobotPlayer {
    static void runSage() throws GameActionException {

    }
}