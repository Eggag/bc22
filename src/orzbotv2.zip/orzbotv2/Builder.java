package orzbotv2;

import battlecode.common.*;

import java.util.ArrayList;
import java.util.Map;

public class Builder extends RobotPlayer {
    static void runBuilder() throws GameActionException {

    }
}